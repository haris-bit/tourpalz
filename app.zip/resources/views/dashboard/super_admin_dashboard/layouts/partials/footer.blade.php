<footer class="footer">
            © 2022 Adcode by thinkabt.com
        </footer>